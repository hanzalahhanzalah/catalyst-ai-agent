# 🏆 #AISeekho 2026 — Winning Implementation Plan
## Challenge 1: Autonomous Content-to-Action Agent (Insight → Action System)

> **Deadline**: Submission by **20th May 2026** | You have ~2 days left.
> **Goal**: Win by maximizing all judging dimensions, especially the top 3 criteria that account for 65% of the score.

---

## 🎯 Judging Score Strategy

| Criteria | Weight | Our Strategy |
|---|---|---|
| Google Antigravity Integration | **25%** | Antigravity IS the orchestration brain — every agent step runs through it |
| Agentic Reasoning & Workflow | **20%** | Multi-step planner with visible reasoning chains, tool calls, and retries |
| Problem Understanding & Decision Quality | **20%** | 5-source ingestion, contradiction detection, constraint-aware decision engine |
| Action Simulation & Outcome | **15%** | Animated step-by-step execution with before/after state diff |
| Technical Implementation | **10%** | Clean architecture, typed API, robust error handling |
| Innovation, UX & Demo Clarity | **10%** | Premium mobile UI with live trace viewer and outcome dashboard |

**Total Score Target: 90%+**

---

## 🛠️ Selected Tech Stack

> Chosen for maximum quality, speed, and deep Antigravity integration.

### Mobile App (Mandatory)
| Layer | Technology | Reason |
|---|---|---|
| Framework | **React Native + Expo** | Cross-platform (iOS/Android), fast build, rich ecosystem |
| UI Library | **React Native Paper + Custom** | Material Design base + custom glassmorphism styling |
| Charts | **Victory Native** | Beautiful animated charts for outcome visualization |
| State Management | **Zustand** | Lightweight, no boilerplate, perfect for agent state |
| Navigation | **Expo Router** | File-based routing, clean structure |
| Animations | **React Native Reanimated 3** | Smooth step animations, entry effects |
| HTTP Client | **Axios** | Clean API calls with interceptors |

### Backend (Agent Brain)
| Layer | Technology | Reason |
|---|---|---|
| Runtime | **Python 3.12 + FastAPI** | Async support, typed, fast to develop |
| Agent Orchestration | **Google Gemini 2.0 Flash** via `google-generativeai` | Core Antigravity model — function calling, planning |
| Document Parsing | **PyMuPDF (fitz)** | Best PDF extraction library |
| Web Scraping | **httpx + BeautifulSoup4** | Lightweight article/webpage ingestion |
| Data Processing | **Pandas + NumPy** | CSV/JSON analysis and temporal trend detection |
| Database | **SQLite (local)** — upgrade path to Supabase | Zero-config for hackathon, stores agent traces/state |
| Caching | **Redis (optional)** / in-memory dict | Rate-limit management and deduplication |
| Server | **Uvicorn** | ASGI, async-native, fast |

### Google Antigravity Integration Points
- **Gemini 2.0 Flash** as the reasoning core (function calling enabled)
- **Antigravity tool calls** logged at every step (workplan, task plan, action execution)
- **Agent traces exported** as JSON for demo submission
- All tool invocations routed through Antigravity's reasoning loop

---

## 📁 Project Structure

```
AISeekho-Agent/
├── mobile/                          # React Native Expo App
│   ├── app/
│   │   ├── (tabs)/
│   │   │   ├── index.tsx            # Home / Upload Sources
│   │   │   ├── insights.tsx         # Insight & Contradiction View
│   │   │   ├── actions.tsx          # Action Chain Simulation
│   │   │   ├── outcome.tsx          # Before/After Dashboard
│   │   │   └── trace.tsx            # Antigravity Agent Trace Viewer
│   │   └── _layout.tsx
│   ├── components/
│   │   ├── SourceCard.tsx
│   │   ├── InsightBubble.tsx
│   │   ├── ActionStep.tsx
│   │   ├── ContradictionAlert.tsx
│   │   ├── OutcomeChart.tsx
│   │   └── TraceLog.tsx
│   ├── store/
│   │   └── agentStore.ts            # Zustand state
│   ├── services/
│   │   └── api.ts                   # Backend API client
│   └── constants/
│       └── theme.ts                 # Design tokens
│
├── backend/                         # FastAPI Python Backend
│   ├── main.py                      # FastAPI app entry point
│   ├── agent/
│   │   ├── orchestrator.py          # Main Antigravity agent loop
│   │   ├── planner.py               # Workplan + task plan generation
│   │   ├── tools.py                 # All tool definitions for Gemini
│   │   ├── contradiction.py         # Contradiction detection logic
│   │   ├── constraint_engine.py     # Budget/time/urgency constraints
│   │   └── recovery.py              # Failure recovery & rollback
│   ├── ingestors/
│   │   ├── pdf_ingestor.py
│   │   ├── web_ingestor.py
│   │   ├── csv_ingestor.py
│   │   ├── json_ingestor.py
│   │   └── feed_ingestor.py         # Mock real-time feed
│   ├── models/
│   │   ├── source.py
│   │   ├── insight.py
│   │   ├── action.py
│   │   └── trace.py
│   ├── db/
│   │   └── database.py              # SQLite connection + schema
│   ├── routers/
│   │   ├── ingest.py
│   │   ├── analyze.py
│   │   ├── execute.py
│   │   └── trace.py
│   ├── demo_data/                   # Pre-built 5-source scenario
│   │   ├── warehouse.csv
│   │   ├── supplier_email.pdf
│   │   ├── sales_dashboard.json
│   │   ├── complaints_feed.json
│   │   └── news_article_url.txt
│   └── requirements.txt
│
├── README.md
└── demo/
    ├── agent_trace.json             # Exported trace for judges
    └── demo_script.md
```

---

## 🚀 Implementation Phases

### ⏱️ Timeline: 18 May (Night) → 20 May (Noon) = ~36 hours

---

### Phase 1: Foundation & Backend Core *(~8 hours | Day 1 Night)*

**Goal**: Get the FastAPI backend running with Gemini 2.0 integrated and ingestion pipeline working.

#### 1.1 — Project Setup
- [ ] Create `d:\hackathon\AISeekho-Agent\` directory structure
- [ ] Initialize Python virtual environment with `requirements.txt`
- [ ] Initialize Expo app with `npx create-expo-app@latest`
- [ ] Set up SQLite database schema (sources, insights, actions, traces tables)

#### 1.2 — Multi-Source Ingestion Pipeline
- [ ] **PDF Ingestor**: Extract text + metadata using PyMuPDF
- [ ] **Web Ingestor**: Fetch article content using httpx + BeautifulSoup
- [ ] **CSV/JSON Ingestor**: Parse structured data using Pandas, extract column summaries + time series
- [ ] **Mock Real-Time Feed**: Return mock JSON feed (simulates live RSS/webhook)
- [ ] Normalize all 5 sources into a unified `SourceDocument` schema with: `{id, type, content, timestamp, credibility_score, metadata}`

#### 1.3 — Google Antigravity (Gemini) Agent Core
- [ ] Configure Gemini 2.0 Flash with function calling
- [ ] Define 8 core tools the agent can call:
  - `ingest_source(source_id)` — load and preprocess a source
  - `extract_insights(source_ids)` — extract key signals from sources
  - `detect_contradictions(insights)` — compare and flag conflicts
  - `score_credibility(source_id)` — assign recency + credibility score
  - `generate_action_plan(insights, constraints)` — create 3-5 action chain
  - `execute_action(action_id)` — simulate action execution with state change
  - `handle_failure(action_id, error)` — recovery or rollback
  - `compute_outcome(before_state, after_state)` — calculate metrics delta
- [ ] Build `orchestrator.py`: drives the full agent loop with visible workplan + decision trace
- [ ] Log every Antigravity tool call to the `traces` database table

#### 1.4 — Demo Data Setup
- [ ] Create the 5-source **inventory shortage scenario**:
  - `warehouse.csv` — shows stock levels (stale, says "sufficient")
  - `supplier_email.pdf` — delayed shipment notice
  - `sales_dashboard.json` — sales surge data (last 7 days)
  - `complaints_feed.json` — customer delivery complaints (mock real-time)
  - `news_article_url` — transport delay news article
- [ ] Data is pre-crafted so the agent finds a contradiction (warehouse CSV is stale vs newer sources)

---

### Phase 2: Agent Intelligence Layer *(~8 hours | Day 2 Morning)*

**Goal**: Build contradiction detection, constraint engine, and action chain simulation.

#### 2.1 — Contradiction Detection
- [ ] Compare same metrics across sources (e.g., "stock level" in CSV vs feed)
- [ ] Score each source: `credibility = base_score * recency_weight`
- [ ] Flag conflicts with: `{metric, source_a, source_b, value_a, value_b, winner, reason}`
- [ ] Generate investigation path when conflict is unresolvable
- [ ] Output: structured `ContradictionReport`

#### 2.2 — Noise Filtering
- [ ] Detect duplicate signals (cosine similarity via sentence embeddings or keyword overlap)
- [ ] Mark sources as stale if timestamp > threshold
- [ ] Down-rank low-credibility sources
- [ ] Filter irrelevant content using keyword/topic relevance scoring

#### 2.3 — Temporal Analysis
- [ ] Parse timestamps across all sources
- [ ] Build time-series for key metrics (stock level, complaints, sales)
- [ ] Detect trend direction: rising / falling / spike / stable
- [ ] Identify divergence points (where sources start disagreeing)

#### 2.4 — Constraint-Based Action Planner
- [ ] Define `ConstraintProfile`: `{budget_pkr, time_limit_hours, resource_units, urgency_level, api_rate_limit}`
- [ ] Agent generates 3-5 action plan, each action has:
  - `{id, name, type, cost_estimate, time_estimate, dependencies, status}`
- [ ] Constraint engine validates each action: reject/modify if infeasible
- [ ] Rejected actions are logged with reason (e.g., "exceeds emergency order budget")

#### 2.5 — Action Simulation Engine
- [ ] Each action mutates `SystemState` (a dict representing the world state)
- [ ] Actions are: `VALIDATE_STOCK → NOTIFY_PROCUREMENT → SIMULATE_EMERGENCY_ORDER → UPDATE_DELIVERY_ESTIMATES → SCHEDULE_MONITORING`
- [ ] Each step emits: `{action_id, before_state, after_state, cost, latency_ms, status}`
- [ ] If an action fails (random 20% chance in demo mode), `recovery.py` retries or substitutes

#### 2.6 — Failure Recovery
- [ ] Retry logic: up to 3 attempts with exponential backoff (simulated)
- [ ] Fallback substitution: if emergency order fails → contact secondary supplier
- [ ] Partial rollback: if a state mutation is invalid, revert to prior checkpoint
- [ ] All recovery steps logged in trace

---

### Phase 3: FastAPI Routes & Real-Time Streaming *(~4 hours | Day 2 Midday)*

**Goal**: Expose all agent capabilities via clean REST + Server-Sent Events (SSE).

#### 3.1 — API Endpoints
```
POST /api/ingest          — Upload/register source files
POST /api/analyze         — Trigger full agent analysis pipeline
GET  /api/insights        — Get extracted insights + contradictions
POST /api/execute         — Start action chain simulation
GET  /api/execute/stream  — SSE: stream action execution steps live
GET  /api/outcome         — Get before/after outcome metrics
GET  /api/trace           — Get full Antigravity agent trace
GET  /api/trace/export    — Download trace as JSON (for judges)
GET  /api/demo/load       — Load pre-built 5-source demo scenario
```

#### 3.2 — Server-Sent Events (SSE)
- [ ] Stream action execution steps to mobile app in real-time
- [ ] Each SSE event: `{step, action_name, status, state_delta, latency, timestamp}`
- [ ] Mobile app renders each step as it arrives (animated timeline)

#### 3.3 — Antigravity Trace Logger
- [ ] Every agent decision, tool call, and state change stored in SQLite
- [ ] Exportable as: structured JSON (for judges), human-readable Markdown

---

### Phase 4: Mobile App UI *(~10 hours | Day 2 Afternoon + Evening)*

**Goal**: Build a stunning, premium mobile app with 5 key screens.

#### Design System
- **Color Palette**: Dark navy `#0A0F1E` base, electric blue `#3B82F6` accent, neon green `#10B981` for success, amber `#F59E0B` for warnings, red `#EF4444` for failures
- **Typography**: Inter font (Google Fonts via Expo)
- **Style**: Glassmorphism cards, subtle gradients, smooth Reanimated animations

#### Screen 1: Home / Source Upload (`index.tsx`)
- [ ] Hero header: "Intelligence → Action" with animated subtitle
- [ ] "Load Demo Scenario" button (pre-fills all 5 sources instantly)
- [ ] 5 source slots, each with type icon (PDF, URL, CSV, JSON, Feed)
- [ ] Source credibility badge after analysis
- [ ] "Run Agent Analysis" CTA button (animated pulse)

#### Screen 2: Insights & Contradictions (`insights.tsx`)
- [ ] Scrollable list of extracted insights, color-coded by type (risk/opportunity/trend)
- [ ] **Contradiction Alert Card**: shows conflicting sources, winner, and why
- [ ] Noise filter summary: "3 signals filtered as stale/duplicate"
- [ ] Temporal trend mini-charts (Victory Native sparklines)
- [ ] Each insight tappable → expanded detail view

#### Screen 3: Action Chain (`actions.tsx`)
- [ ] Animated vertical timeline of 5 actions
- [ ] Each action card shows: name, type, estimated cost (PKR), time, status
- [ ] ⚠️ Constraint violation badge if action was rejected/modified
- [ ] "Simulate Execution" button → streams action execution via SSE
- [ ] Live step-by-step animation: pending → running → success/failure
- [ ] Failure recovery flow shown inline (retry badge, fallback action)

#### Screen 4: Outcome Dashboard (`outcome.tsx`)
- [ ] **Before vs After** comparison cards
- [ ] Key metrics: Stockout Risk (%), Supplier Status, Customer Notifications Sent, Total Cost
- [ ] Victory Native bar/line charts for visual impact
- [ ] Cost/Latency summary (total PKR spent, total ms elapsed)
- [ ] "Projected Impact" section (predicted 7-day outcome)

#### Screen 5: Agent Trace Viewer (`trace.tsx`)
- [ ] Scrollable log of every Antigravity decision
- [ ] Each entry: `{timestamp, type, tool_called, input, output, reasoning}`
- [ ] Color-coded: blue=planning, green=tool call, amber=constraint check, red=failure, purple=recovery
- [ ] "Export Trace" button → share as JSON file
- [ ] Filter buttons: All / Reasoning / Tool Calls / Failures

---

### Phase 5: Integration & Polish *(~4 hours | Day 2 Late Evening)*

**Goal**: Wire everything together, fix bugs, polish animations.

- [ ] Connect mobile app to all backend API endpoints
- [ ] Test full end-to-end flow: load demo → analyze → execute → view outcome
- [ ] Ensure SSE streaming works on device (Expo Go or build)
- [ ] Add loading states, error boundaries, empty states
- [ ] Optimize animation performance (60fps on mid-range Android)
- [ ] Test failure/recovery scenario manually
- [ ] Verify Antigravity trace captures all required judge-visible steps

---

### Phase 6: Demo Video & Submission Assets *(~4 hours | Day 3 Morning)*

**Goal**: Create the 3-5 min demo video and all submission deliverables.

#### Demo Video Script (3-5 minutes)
1. **(0:00-0:30)** — Problem statement narration + app intro screen
2. **(0:30-1:00)** — Load demo: show 5 sources being ingested
3. **(1:00-1:45)** — Agent analysis: watch insights appear, contradiction detected (warehouse CSV is stale)
4. **(1:45-2:30)** — Action chain: 5 actions generated, show constraint rejection (budget exceeded → modified)
5. **(2:30-3:30)** — Simulate execution: live animation, action 3 fails → recovery kicks in
6. **(3:30-4:00)** — Outcome dashboard: before vs after, charts, cost/latency
7. **(4:00-4:30)** — Trace viewer: show Antigravity's full decision log
8. **(4:30-5:00)** — Closing summary: architecture overview, innovation highlights

#### README Sections
- [ ] Architecture diagram (component flow)
- [ ] Data sources used + why
- [ ] Antigravity role (how it's central, not peripheral)
- [ ] Assumptions & constraints
- [ ] Cost/latency analysis (table format)
- [ ] Baseline comparison (rule-based system vs our agent)
- [ ] Known limitations + future roadmap

#### Submission Package
- [ ] APK build (or Expo link) for mobile app
- [ ] Backend deployed (Railway.app free tier or localhost + ngrok)
- [ ] `agent_trace.json` — full exported trace
- [ ] Demo video (screen record + voiceover)
- [ ] README.md

---

## 🧠 Key Winning Differentiators

### 1. Antigravity is the BRAIN, not decoration
Every decision — contradiction resolution, constraint checking, action selection, recovery — passes through the Gemini function-calling loop. Judges can trace every reasoning step.

### 2. The Contradiction Scene is the WOW Moment
When the agent discovers the warehouse CSV is 3 days old and conflicts with the live complaint feed, it shows a clear resolution: "Older source down-ranked. Stock shortage confirmed." This is exactly what judges want to see.

### 3. Live Action Simulation with Failure Recovery
The demo shows action 3 (Emergency Order) failing (simulated API timeout), then the agent automatically substituting a secondary supplier contact. This proves robustness.

### 4. The Trace Viewer is Judge Gold
Having a dedicated screen showing every Antigravity reasoning step, tool call, and decision gives judges exactly what they need to evaluate agentic reasoning without digging into logs.

### 5. Premium Mobile UX
Dark glassmorphism UI with animated timelines and real-time streaming is far above typical hackathon submissions. This wins the Innovation/UX 10%.

---

## ⚠️ Open Questions / Decisions

> [!IMPORTANT]
> **API Key**: You need a Google AI (Gemini) API key set as `GEMINI_API_KEY`. Do you have one, or should I use a mock/stub mode?

> [!IMPORTANT]
> **Testing Device**: Will you run the mobile app on Expo Go (phone) or Android Emulator? This affects how we configure the backend URL.

> [!WARNING]
> **Time**: Submission is 20th May. With ~2 days, we must start Phase 1 immediately. Approve this plan now so we can begin coding.

> [!NOTE]
> **Deployment**: For judges to test the backend, we'll expose it via `ngrok` or deploy to Railway.app (free). The mobile app will be an Expo preview link or APK.

---

## ✅ Verification Plan

### Functional Tests
- Full pipeline: 5 sources → analysis → 5 actions → simulation → outcome
- Contradiction correctly identified (warehouse CSV vs live feed)
- Budget-exceeding action correctly rejected by constraint engine
- Failure + recovery flow triggers and logs correctly
- Trace export produces valid JSON with all required fields

### Demo Dry-Run
- Full 5-minute demo recorded without errors
- All 5 screens navigable and populated with real agent data
- SSE streaming visible in real-time on action screen

### Judge Submission Checklist
- [ ] Mobile APK / Expo link working
- [ ] Backend URL live and accessible
- [ ] `agent_trace.json` exported and attached
- [ ] Demo video 3-5 minutes, crisp audio/video
- [ ] README complete with all required sections
